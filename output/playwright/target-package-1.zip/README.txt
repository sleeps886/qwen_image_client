单目标预测样本包
仅将 input/observations.json 导入轨迹工作台，内含全部平台的起始经纬度、航向、航速、hull/tow偏移。
input/platform.json 为相同平台参数的独立副本；start_ll 顺序为[纬度,经度]，航向北0度顺时针，速度kn，阵列偏移米。
evaluation/reference.json 和 plots/trajectory.png 是完整可见时间内的轨迹真值，仅用于对比，不能作为预测输入。
观测是仿真理想方位中心，不是图片高斯测量；单目标分组是已知答案，不用于检验混合目标关联。
稀疏点严格沿用原混合观测的抽样，没有补造数据。若无观测，不能用于预测，请提高保留比例或调整可见窗口。
